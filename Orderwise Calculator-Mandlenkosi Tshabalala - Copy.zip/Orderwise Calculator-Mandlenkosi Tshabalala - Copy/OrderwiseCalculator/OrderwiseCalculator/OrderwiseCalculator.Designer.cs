﻿namespace OrderwiseCalculator
{
    partial class OrderwiseCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.CE = new System.Windows.Forms.Button();
            this.Percent = new System.Windows.Forms.Button();
            this.OverOne = new System.Windows.Forms.Button();
            this.SquareRoot = new System.Windows.Forms.Button();
            this.Squared = new System.Windows.Forms.Button();
            this.Negate = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.Comma = new System.Windows.Forms.Button();
            this.Divide = new System.Windows.Forms.Button();
            this.Equals = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Multiply = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Minus = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Zero = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.StepBack = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Display = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CE);
            this.panel1.Controls.Add(this.Percent);
            this.panel1.Controls.Add(this.OverOne);
            this.panel1.Controls.Add(this.SquareRoot);
            this.panel1.Controls.Add(this.Squared);
            this.panel1.Controls.Add(this.Negate);
            this.panel1.Controls.Add(this.Two);
            this.panel1.Controls.Add(this.Comma);
            this.panel1.Controls.Add(this.Divide);
            this.panel1.Controls.Add(this.Equals);
            this.panel1.Controls.Add(this.Add);
            this.panel1.Controls.Add(this.Multiply);
            this.panel1.Controls.Add(this.Three);
            this.panel1.Controls.Add(this.Minus);
            this.panel1.Controls.Add(this.Six);
            this.panel1.Controls.Add(this.Zero);
            this.panel1.Controls.Add(this.Five);
            this.panel1.Controls.Add(this.Clear);
            this.panel1.Controls.Add(this.Nine);
            this.panel1.Controls.Add(this.StepBack);
            this.panel1.Controls.Add(this.Eight);
            this.panel1.Controls.Add(this.Four);
            this.panel1.Controls.Add(this.One);
            this.panel1.Controls.Add(this.Seven);
            this.panel1.Location = new System.Drawing.Point(7, 93);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(506, 566);
            this.panel1.TabIndex = 0;
            // 
            // CE
            // 
            this.CE.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.CE.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CE.Location = new System.Drawing.Point(16, 30);
            this.CE.Margin = new System.Windows.Forms.Padding(2);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(76, 85);
            this.CE.TabIndex = 44;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = false;
            this.CE.Click += new System.EventHandler(this.CE_Click);
            // 
            // Percent
            // 
            this.Percent.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Percent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Percent.Location = new System.Drawing.Point(316, 30);
            this.Percent.Margin = new System.Windows.Forms.Padding(2);
            this.Percent.Name = "Percent";
            this.Percent.Size = new System.Drawing.Size(76, 85);
            this.Percent.TabIndex = 43;
            this.Percent.Text = "%";
            this.Percent.UseVisualStyleBackColor = false;
            this.Percent.Click += new System.EventHandler(this.Percent_Click);
            // 
            // OverOne
            // 
            this.OverOne.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.OverOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OverOne.Location = new System.Drawing.Point(316, 144);
            this.OverOne.Margin = new System.Windows.Forms.Padding(2);
            this.OverOne.Name = "OverOne";
            this.OverOne.Size = new System.Drawing.Size(76, 85);
            this.OverOne.TabIndex = 42;
            this.OverOne.Text = "1/x";
            this.OverOne.UseVisualStyleBackColor = false;
            this.OverOne.Click += new System.EventHandler(this.OverOne_Click);
            // 
            // SquareRoot
            // 
            this.SquareRoot.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.SquareRoot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SquareRoot.Location = new System.Drawing.Point(316, 252);
            this.SquareRoot.Margin = new System.Windows.Forms.Padding(2);
            this.SquareRoot.Name = "SquareRoot";
            this.SquareRoot.Size = new System.Drawing.Size(76, 85);
            this.SquareRoot.TabIndex = 41;
            this.SquareRoot.Text = "²√x";
            this.SquareRoot.UseVisualStyleBackColor = false;
            this.SquareRoot.Click += new System.EventHandler(this.SquareRoot_Click);
            // 
            // Squared
            // 
            this.Squared.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Squared.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Squared.Location = new System.Drawing.Point(316, 361);
            this.Squared.Margin = new System.Windows.Forms.Padding(2);
            this.Squared.Name = "Squared";
            this.Squared.Size = new System.Drawing.Size(76, 85);
            this.Squared.TabIndex = 40;
            this.Squared.Text = "x²";
            this.Squared.UseVisualStyleBackColor = false;
            this.Squared.Click += new System.EventHandler(this.Squared_Click);
            // 
            // Negate
            // 
            this.Negate.BackColor = System.Drawing.Color.White;
            this.Negate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Negate.Location = new System.Drawing.Point(218, 467);
            this.Negate.Margin = new System.Windows.Forms.Padding(2);
            this.Negate.Name = "Negate";
            this.Negate.Size = new System.Drawing.Size(76, 85);
            this.Negate.TabIndex = 39;
            this.Negate.Text = "+/-";
            this.Negate.UseVisualStyleBackColor = false;
            this.Negate.Click += new System.EventHandler(this.Negate_Click);
            // 
            // Two
            // 
            this.Two.BackColor = System.Drawing.Color.White;
            this.Two.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two.Location = new System.Drawing.Point(117, 361);
            this.Two.Margin = new System.Windows.Forms.Padding(2);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(76, 85);
            this.Two.TabIndex = 38;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = false;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // Comma
            // 
            this.Comma.BackColor = System.Drawing.Color.White;
            this.Comma.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Comma.Location = new System.Drawing.Point(117, 467);
            this.Comma.Margin = new System.Windows.Forms.Padding(2);
            this.Comma.Name = "Comma";
            this.Comma.Size = new System.Drawing.Size(76, 85);
            this.Comma.TabIndex = 37;
            this.Comma.Text = ".";
            this.Comma.UseVisualStyleBackColor = false;
            this.Comma.Click += new System.EventHandler(this.Comma_Click);
            // 
            // Divide
            // 
            this.Divide.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Divide.Location = new System.Drawing.Point(415, 252);
            this.Divide.Margin = new System.Windows.Forms.Padding(2);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(76, 85);
            this.Divide.TabIndex = 35;
            this.Divide.Text = "/";
            this.Divide.UseVisualStyleBackColor = false;
            this.Divide.Click += new System.EventHandler(this.Divide_Click);
            // 
            // Equals
            // 
            this.Equals.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Equals.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equals.Location = new System.Drawing.Point(316, 467);
            this.Equals.Margin = new System.Windows.Forms.Padding(2);
            this.Equals.Name = "Equals";
            this.Equals.Size = new System.Drawing.Size(174, 85);
            this.Equals.TabIndex = 34;
            this.Equals.Text = "=";
            this.Equals.UseVisualStyleBackColor = false;
            this.Equals.Click += new System.EventHandler(this.Equals_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Location = new System.Drawing.Point(415, 361);
            this.Add.Margin = new System.Windows.Forms.Padding(2);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(76, 85);
            this.Add.TabIndex = 33;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Multiply
            // 
            this.Multiply.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Multiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Multiply.Location = new System.Drawing.Point(415, 30);
            this.Multiply.Margin = new System.Windows.Forms.Padding(2);
            this.Multiply.Name = "Multiply";
            this.Multiply.Size = new System.Drawing.Size(76, 85);
            this.Multiply.TabIndex = 32;
            this.Multiply.Text = "x";
            this.Multiply.UseVisualStyleBackColor = false;
            this.Multiply.Click += new System.EventHandler(this.Multiply_Click);
            // 
            // Three
            // 
            this.Three.BackColor = System.Drawing.Color.White;
            this.Three.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three.Location = new System.Drawing.Point(218, 361);
            this.Three.Margin = new System.Windows.Forms.Padding(2);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(76, 85);
            this.Three.TabIndex = 31;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = false;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // Minus
            // 
            this.Minus.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Minus.Location = new System.Drawing.Point(414, 144);
            this.Minus.Margin = new System.Windows.Forms.Padding(2);
            this.Minus.Name = "Minus";
            this.Minus.Size = new System.Drawing.Size(76, 85);
            this.Minus.TabIndex = 30;
            this.Minus.Text = "-";
            this.Minus.UseVisualStyleBackColor = false;
            this.Minus.Click += new System.EventHandler(this.Minus_Click);
            // 
            // Six
            // 
            this.Six.BackColor = System.Drawing.Color.White;
            this.Six.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six.Location = new System.Drawing.Point(218, 252);
            this.Six.Margin = new System.Windows.Forms.Padding(2);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(76, 85);
            this.Six.TabIndex = 29;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = false;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // Zero
            // 
            this.Zero.BackColor = System.Drawing.Color.White;
            this.Zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero.Location = new System.Drawing.Point(16, 467);
            this.Zero.Margin = new System.Windows.Forms.Padding(2);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(76, 85);
            this.Zero.TabIndex = 28;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = false;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // Five
            // 
            this.Five.BackColor = System.Drawing.Color.White;
            this.Five.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five.Location = new System.Drawing.Point(117, 252);
            this.Five.Margin = new System.Windows.Forms.Padding(2);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(76, 85);
            this.Five.TabIndex = 27;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = false;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Clear
            // 
            this.Clear.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.Location = new System.Drawing.Point(117, 30);
            this.Clear.Margin = new System.Windows.Forms.Padding(2);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(76, 85);
            this.Clear.TabIndex = 26;
            this.Clear.Text = "C";
            this.Clear.UseVisualStyleBackColor = false;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Nine
            // 
            this.Nine.BackColor = System.Drawing.Color.White;
            this.Nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nine.Location = new System.Drawing.Point(218, 144);
            this.Nine.Margin = new System.Windows.Forms.Padding(2);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(76, 85);
            this.Nine.TabIndex = 25;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = false;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // StepBack
            // 
            this.StepBack.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.StepBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StepBack.Location = new System.Drawing.Point(218, 30);
            this.StepBack.Margin = new System.Windows.Forms.Padding(2);
            this.StepBack.Name = "StepBack";
            this.StepBack.Size = new System.Drawing.Size(76, 85);
            this.StepBack.TabIndex = 24;
            this.StepBack.Text = "<";
            this.StepBack.UseVisualStyleBackColor = false;
            this.StepBack.Click += new System.EventHandler(this.StepBack_Click);
            // 
            // Eight
            // 
            this.Eight.BackColor = System.Drawing.Color.White;
            this.Eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight.Location = new System.Drawing.Point(117, 144);
            this.Eight.Margin = new System.Windows.Forms.Padding(2);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(76, 85);
            this.Eight.TabIndex = 23;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = false;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Four
            // 
            this.Four.BackColor = System.Drawing.Color.White;
            this.Four.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four.Location = new System.Drawing.Point(16, 252);
            this.Four.Margin = new System.Windows.Forms.Padding(2);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(76, 85);
            this.Four.TabIndex = 22;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = false;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // One
            // 
            this.One.BackColor = System.Drawing.Color.White;
            this.One.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One.Location = new System.Drawing.Point(16, 361);
            this.One.Margin = new System.Windows.Forms.Padding(2);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(76, 85);
            this.One.TabIndex = 21;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = false;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // Seven
            // 
            this.Seven.BackColor = System.Drawing.Color.White;
            this.Seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven.Location = new System.Drawing.Point(16, 144);
            this.Seven.Margin = new System.Windows.Forms.Padding(2);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(76, 85);
            this.Seven.TabIndex = 19;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = false;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Display
            // 
            this.Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Display.Location = new System.Drawing.Point(9, 10);
            this.Display.Margin = new System.Windows.Forms.Padding(2);
            this.Display.Name = "Display";
            this.Display.Size = new System.Drawing.Size(506, 79);
            this.Display.TabIndex = 1;
            this.Display.Text = "";
            // 
            // OrderwiseCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 670);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "OrderwiseCalculator";
            this.Text = "OrderwiseCalculator";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Two;
        private System.Windows.Forms.Button Comma;
        private System.Windows.Forms.Button Divide;
        private System.Windows.Forms.Button Equals;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Multiply;
        private System.Windows.Forms.Button Three;
        private System.Windows.Forms.Button Minus;
        private System.Windows.Forms.Button Six;
        private System.Windows.Forms.Button Zero;
        private System.Windows.Forms.Button Five;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Nine;
        private System.Windows.Forms.Button StepBack;
        private System.Windows.Forms.Button Four;
        private System.Windows.Forms.Button One;
        private System.Windows.Forms.Button Seven;
        private System.Windows.Forms.RichTextBox Display;
        private System.Windows.Forms.Button Negate;
        private System.Windows.Forms.Button SquareRoot;
        private System.Windows.Forms.Button Squared;
        private System.Windows.Forms.Button Eight;
        private System.Windows.Forms.Button CE;
        private System.Windows.Forms.Button Percent;
        private System.Windows.Forms.Button OverOne;
    }
}

