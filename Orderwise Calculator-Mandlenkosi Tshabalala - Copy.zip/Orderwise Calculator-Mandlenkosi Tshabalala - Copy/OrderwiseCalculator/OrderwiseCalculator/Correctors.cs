﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderwiseCalculator
{
    public class Correctors
    {
        public string Clear(string text)  // clears all text
        {
            return "";
        }

        public string StepBack(string text)  // clears the most recent charactor
        {
            return text.Substring(0,text.Length-1);
        }
    }
}
