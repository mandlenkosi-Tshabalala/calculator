﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderwiseCalculator
{
    public class Validation
    {
        static public bool isValid(string text)// checks if entered input is valid
        {
            bool previousNumber = isNumber(text.Substring(0, 1));
            bool previousComma = isComma(text.Substring(0, 1));
            bool previousOperator = isOperator(text.Substring(0, 1));
            bool isZero = false;
            //bool partOfNumber = false;
            bool commaPressed = false;

            if ((previousComma || previousOperator) && text.Substring(0, 1) != "-")
            {
                return false;
            }


            if (!isNumber(text.Substring(text.Length - 1)) && text.Substring(text.Length - 1) != "²")
            {
                return false;
            }

            for (int i = 0; i < text.Length; i++)
            {
                if (i < text.Length - 1)
                {
                    if (text[i].ToString() == "²" && text[i + 1].ToString() == "²")
                    {
                        return false;
                    }
                }

            }

            for (int i = 0; i < text.Length; i++)
            {
                if (i < text.Length - 1)
                {
                    if (text[i].ToString() == "√" && text[i + 1].ToString() == "√")
                    {
                        return false;
                    }
                }

            }


            for (int i = 0; i < text.Length; i++)
            {
                if (isComma(text[i].ToString()))
                {
                    if (previousComma)
                    {
                        return false;
                    }

                    if (previousOperator)
                    {
                        return false;
                    }

                    if (commaPressed)
                    {
                        return false;
                    }

                    previousNumber = false;
                    previousComma = true;
                    previousOperator = false;

                    commaPressed = true;

                    isZero = false;
                }

                else if (isOperator(text[i].ToString()))
                {
                    if (previousComma)
                    {
                        return false;
                    }

                    if (previousOperator && text[i].ToString() != "-")
                    {
                        return false;
                    }

                    previousNumber = false;
                    previousComma = false;
                    previousOperator = true;

                    commaPressed = false;

                    isZero = false;
                }

                else if (isNumber(text[i].ToString()))
                {
                    if (isZero == true)
                    {
                        return false;
                    }

                    if (i == text.Length - 1)
                    {
                        //if (previousOperator && (text.Substring(i - 1, 1) == "/") && (text.Substring(i, 1) == "0"))
                        //{
                        //    return false;
                        //}
                    }

                    else
                    {
                        if (previousOperator && (text.Substring(i - 1, 1) == "/") && (text.Substring(i + 1, 1) != ".") && (text.Substring(i + 1, 1) != ",") && (text.Substring(i, 1) == "0"))
                        {
                            return false;
                        }
                    }




                    if (previousOperator && (text.Substring(i, 1) == "0"))
                    {
                        isZero = true;
                    }

                    else
                    {
                        isZero = false;
                    }

                    //partOfNumber = true;
                    previousNumber = true;
                    previousComma = false;
                    previousOperator = false;


                }
            }
            return true;
        }

        static public bool isNumber(string text)// returns true if character is a number 
        {
            if (Char.IsDigit(text, 0))
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        static public bool isComma(string text)// returns true if character is a COMMA 
        {
            if (text == "." || text == ",")
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        static public bool isOperator(string text)// returns true if character is an operator 
        {
            if (text == "+" || text == "-" || text == "x" || text == "/")
            {
                return true;
            }

            else
            {
                return false;
            }
        }
    }
}
