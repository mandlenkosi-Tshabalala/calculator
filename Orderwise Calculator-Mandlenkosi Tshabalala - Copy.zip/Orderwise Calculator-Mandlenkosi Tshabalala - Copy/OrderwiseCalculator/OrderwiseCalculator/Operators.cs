﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderwiseCalculator
{
    public class Operators
    {
        public static Decimal Add(Decimal num1, Decimal num2)  // adds two numbers
        {
            return num1 + num2;
        }
        public static Decimal Multiply(Decimal num1, Decimal num2)  // multiplies two numbers
        {
            return num1 * num2;
        }
        public static Decimal Divide(Decimal num1, Decimal num2)  // divides two numbers
        {

            return num1 / num2;
        }
        public static Decimal Subtract(Decimal num1, Decimal num2)  // subtracts two numbers
        {
            return num1 - num2;
        }

        public static Decimal Squared(Decimal num1)  // subtracts two numbers
        {
            return num1 * num1;
        }


        public static Decimal SquareRoot(Decimal num1)  // subtracts two numbers
        {
            return (decimal)Math.Sqrt((double)num1) ;
        }


        public static Decimal Pencent(Decimal num1)  // adds two numbers
        {
            return num1 * (decimal)0.01;
        }

        public static string CalculationLogic(string input)  // subtracts two numbers
        {
            if (input == "")
            {
                input = "Nothing entered";
            }
            else if (!Validation.isValid(input))
            {
                input = "Input entered is not valid";
            }
            else
            {
                decimal num1 = 0;
                decimal num2 = 0;
                decimal total = 0;

                int k = -1;
                int l = -1;



                var numberToCalculate = "";
                var position = 0;
                for (int i = 0; i < input.Length; i++)
                {
                    if (input.Substring(i, 1) == "²")
                    {
                        for (int j = i - 1; j >= 0; j--)
                        {
                            if (Validation.isOperator(input.Substring(j, 1)) || j == 0)
                            {

                                if (j == 0)
                                {
                                    numberToCalculate = input.Substring(j, i);
                                    position = j;
                                    if (numberToCalculate.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(numberToCalculate);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(numberToCalculate, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    total = Operators.Squared(num1);
                                    input = total + input.Substring(i + 1);
                                    break;
                                }
                                else
                                {
                                    numberToCalculate = input.Substring(j + 1, i - (j + 1));
                                    position = j;
                                    if (numberToCalculate.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(numberToCalculate);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(numberToCalculate, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    total = Operators.Squared(num1);
                                    input = input.Substring(0, j + 1) + total + input.Substring(i + 1);
                                    break;
                                }

                            }
                        }
                    }
                }








                numberToCalculate = "";
                position = 0;
                for (int i = 0; i < input.Length; i++)
                {
                    if (input.Substring(i, 1) == "√")
                    {
                        for (int j = i + 1; j < input.Length; j++)
                        {
                            if (Validation.isOperator(input.Substring(j, 1)) || j == input.Length - 1)
                            {

                                if (j == input.Length - 1)
                                {
                                    numberToCalculate = input.Substring(i + 1, j - i);
                                    position = j;
                                    if (numberToCalculate.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(numberToCalculate);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(numberToCalculate, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    total = Operators.SquareRoot(num1);
                                    string[] array = input.Split('√');
                                    input = array[0] + total;
                                    break;
                                }
                                else
                                {
                                    numberToCalculate = input.Substring(i + 1, j - (i + 1));
                                    position = j;
                                    if (numberToCalculate.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(numberToCalculate);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(numberToCalculate, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    total = Operators.SquareRoot(num1);
                                    input = input.Substring(0, i) + total + input.Substring(i + 1);
                                    break;
                                }

                            }
                        }
                    }
                }







            Restart1:
                for (int i = 0; i < input.Length; i++)
                {
                    k = -1;
                    l = -1;
                    if (i != 0 && Validation.isOperator(input.Substring(i, 1)) && !Validation.isOperator(input.Substring(i - 1, 1)))
                    {
                        if (input.Substring(i, 1) == "/")
                        {
                            for (int j = i - 1; j > -1; j--)
                            {
                                if (j != 0 && Validation.isOperator(input.Substring(j, 1)) && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum1 = input.Substring(j + 1, i - 1 - j);
                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    k = j;
                                    break;
                                }

                                else if (j == 0)
                                {
                                    string stringNum1 = input.Substring(j, i - j);

                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    break;
                                }
                            }

                            for (int j = i + 1; j < input.Length; j++)
                            {

                                if (Validation.isOperator(input.Substring(j, 1)) && j != i + 1 && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum2 = input.Substring(i + 1, j - 1 - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                                    l = j;
                                    break;
                                }

                                else if (j == input.Length - 1)
                                {
                                    string stringNum2 = input.Substring(i + 1, j - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - i), System.Globalization.CultureInfo.InvariantCulture);
                                    break;
                                }
                            }


                            try
                            {
                                total = Operators.Divide(num1, num2);
                            }
                            catch
                            {
                                input = "Attempted to divide by zero";
                                break;
                            }



                            //i = 0;
                            if (k == -1 && l != -1)
                            {
                                input = total + input.Substring(l);
                                goto Restart1;
                            }

                            else if (l == -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total;
                                goto Restart1;
                            }

                            else if (l != -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total + input.Substring(l);
                                goto Restart1;
                            }

                            else
                            {
                                input = total.ToString();
                                goto Restart1;
                            }
                        }


                    }
                }

            Restart2:
                for (int i = 0; i < input.Length; i++)
                {
                    k = -1;
                    l = -1;

                    if (i != 0 && Validation.isOperator(input.Substring(i, 1)) && !Validation.isOperator(input.Substring(i - 1, 1)))
                    {
                        if (input.Substring(i, 1) == "x")
                        {
                            for (int j = i - 1; j > -1; j--)
                            {
                                if (j != 0 && Validation.isOperator(input.Substring(j, 1)) && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum1 = input.Substring(j + 1, i - 1 - j);
                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    k = j;
                                    break;
                                }

                                else if (j == 0)
                                {
                                    string stringNum1 = input.Substring(j, i - j);

                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    break;
                                }
                            }

                            for (int j = i + 1; j < input.Length; j++)
                            {
                                if (Validation.isOperator(input.Substring(j, 1)) && j != i + 1 && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum2 = input.Substring(i + 1, j - 1 - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                                    l = j;
                                    break;
                                }

                                else if (j == input.Length - 1)
                                {
                                    string stringNum2 = input.Substring(i + 1, j - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - i), System.Globalization.CultureInfo.InvariantCulture);
                                    break;
                                }
                            }
                            //for (int j = i - 1; j > -1; j--)
                            //{
                            //    if (Validation.isOperator(input.Substring(j, 1)))
                            //    {
                            //        num1 = Decimal.Parse(input.Substring(j + 1, i - 1 - j), System.Globalization.CultureInfo.InvariantCulture);
                            //        k = j;
                            //        break;
                            //    }

                            //    else if (j == 0)
                            //    {
                            //        num1 = Decimal.Parse(input.Substring(j, i - j), System.Globalization.CultureInfo.InvariantCulture);
                            //        break;
                            //    }
                            //}

                            //for (int j = i + 1; j < input.Length; j++)
                            //{
                            //    if (Validation.isOperator(input.Substring(j, 1)))
                            //    {
                            //        num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                            //        l = j;
                            //        break;
                            //    }

                            //    else if (j == input.Length - 1)
                            //    {
                            //        num2 = Decimal.Parse(input.Substring(i + 1, j - i), System.Globalization.CultureInfo.InvariantCulture);
                            //        break;
                            //    }
                            //}
                            total = Operators.Multiply(num1, num2);
                            //i = 0;
                            if (k == -1 && l != -1)
                            {
                                input = total + input.Substring(l);
                                goto Restart2;
                            }

                            else if (l == -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total;
                                goto Restart2;
                            }

                            else if (l != -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total + input.Substring(l);
                                goto Restart2;
                            }

                            else
                            {
                                input = total.ToString();
                                goto Restart2;
                            }
                        }


                    }
                }
            Restart3:
                for (int i = 0; i < input.Length; i++)
                {
                    k = -1;
                    l = -1;
                    if (i != 0 && Validation.isOperator(input.Substring(i, 1)) && !Validation.isOperator(input.Substring(i - 1, 1)))
                    {
                        if (input.Substring(i, 1) == "+")
                        {
                            //for (int j = i-1; j > -1; j--)
                            //{
                            //    if (Validation.isOperator(input.Substring(j, 1)))
                            //    {
                            //        num1 = Decimal.Parse(input.Substring(j + 1, i - 1 - j), System.Globalization.CultureInfo.InvariantCulture);
                            //        k = j;
                            //        break;
                            //    }

                            //    else if(j==0)
                            //    {
                            //        num1 = Decimal.Parse(input.Substring(j , i-j), System.Globalization.CultureInfo.InvariantCulture);
                            //        break;
                            //    }
                            //}

                            //for (int j = i+1; j < input.Length; j++)
                            //{
                            //    if (Validation.isOperator(input.Substring(j, 1)))
                            //    {
                            //        num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                            //        l = j;
                            //        break;
                            //    }

                            //    else if (j == input.Length-1)
                            //    {
                            //        num2 = Decimal.Parse(input.Substring(i + 1, j-i), System.Globalization.CultureInfo.InvariantCulture);
                            //        break;
                            //    }
                            //}

                            for (int j = i - 1; j > -1; j--)
                            {
                                if (j != 0 && Validation.isOperator(input.Substring(j, 1)) && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum1 = input.Substring(j + 1, i - 1 - j);
                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    k = j;
                                    break;
                                }

                                else if (j == 0)
                                {
                                    string stringNum1 = input.Substring(j, i - j);

                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    break;
                                }
                            }

                            for (int j = i + 1; j < input.Length; j++)
                            {
                                if (Validation.isOperator(input.Substring(j, 1)) && j != i + 1 && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum2 = input.Substring(i + 1, j - 1 - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                                    l = j;
                                    break;
                                }

                                else if (j == input.Length - 1)
                                {
                                    string stringNum2 = input.Substring(i + 1, j - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - i), System.Globalization.CultureInfo.InvariantCulture);
                                    break;
                                }
                            }
                            total = Operators.Add(num1, num2);
                            //i = 0;
                            if (k == -1 && l != -1)
                            {
                                input = total + input.Substring(l);
                                goto Restart3;
                            }

                            else if (l == -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total;
                                goto Restart3;
                            }

                            else if (l != -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total + input.Substring(l);
                                goto Restart3;
                            }

                            else
                            {
                                input = total.ToString();
                                goto Restart3;
                            }
                        }


                    }
                }

            Restart4:
                for (int i = 0; i < input.Length; i++)
                {
                    k = -1;
                    l = -1;
                    if (i != 0 && Validation.isOperator(input.Substring(i, 1)) && !Validation.isOperator(input.Substring(i - 1, 1)))
                    {
                        if (input.Substring(i, 1) == "-" && i != 0 && !Validation.isOperator(input.Substring(i - 1, 1)))
                        {
                            for (int j = i - 1; j > -1; j--)
                            {
                                if (j != 0 && Validation.isOperator(input.Substring(j, 1)) && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum1 = input.Substring(j + 1, i - 1 - j);
                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    k = j;
                                    break;
                                }

                                else if (j == 0)
                                {
                                    string stringNum1 = input.Substring(j, i - j);

                                    if (stringNum1.Contains(","))
                                    {
                                        num1 = Convert.ToDecimal(stringNum1);
                                    }

                                    else
                                    {
                                        num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    break;
                                }
                            }

                            for (int j = i + 1; j < input.Length; j++)
                            {
                                if (Validation.isOperator(input.Substring(j, 1)) && j != i + 1 && !Validation.isOperator(input.Substring(j - 1, 1)))
                                {
                                    string stringNum2 = input.Substring(i + 1, j - 1 - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }

                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                                    l = j;
                                    break;
                                }

                                else if (j == input.Length - 1)
                                {
                                    string stringNum2 = input.Substring(i + 1, j - i);

                                    if (stringNum2.Contains(","))
                                    {
                                        num2 = Convert.ToDecimal(stringNum2);
                                    }

                                    else
                                    {
                                        num2 = Decimal.Parse(stringNum2, System.Globalization.CultureInfo.InvariantCulture);

                                    }
                                    //num2 = Decimal.Parse(input.Substring(i + 1, j - i), System.Globalization.CultureInfo.InvariantCulture);
                                    break;
                                }
                            }
                            //for (int j = i - 1; j > -1; j--)
                            //{
                            //    if (Validation.isOperator(input.Substring(j, 1)))
                            //    {
                            //        num1 = Decimal.Parse(input.Substring(j + 1, i - 1 - j), System.Globalization.CultureInfo.InvariantCulture);
                            //        k = j;
                            //        break;
                            //    }

                            //    else if (j == 0)
                            //    {
                            //        num1 = Decimal.Parse(input.Substring(j, i - j), System.Globalization.CultureInfo.InvariantCulture);
                            //        break;
                            //    }
                            //}

                            //for (int j = i + 1; j < input.Length; j++)
                            //{
                            //    if (Validation.isOperator(input.Substring(j, 1)))
                            //    {
                            //        num2 = Decimal.Parse(input.Substring(i + 1, j - 1 - i), System.Globalization.CultureInfo.InvariantCulture);
                            //        l = j;
                            //        break;
                            //    }

                            //    else if (j == input.Length - 1)
                            //    {
                            //        num2 = Decimal.Parse(input.Substring(i + 1, j - i), System.Globalization.CultureInfo.InvariantCulture);
                            //        break;
                            //    }
                            //}
                            total = Operators.Subtract(num1, num2);
                            //i = 0;
                            if (k == -1 && l != -1)
                            {
                                input = total + input.Substring(l);
                                goto Restart4;
                            }

                            else if (l == -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total;
                                goto Restart4;
                            }

                            else if (l != -1 && k != -1)
                            {
                                input = input.Substring(0, k + 1) + total + input.Substring(l);
                                goto Restart4;
                            }

                            else
                            {
                                input = total.ToString();
                                goto Restart4;
                            }
                        }


                    }
                }
                //if (i == input.Length-1)
                //{
                //    input = total.ToString();
                //}



                //for (int i = 0; i < input.Length;i++ )
                //{
                //    if (operatorIndex == -1)
                //    {
                //        if (Validation.isOperator(input.Substring(i, 1)))
                //        {
                //            total = Convert.ToDecimal(input.Substring(0, i));
                //            operatorIndex = i;
                //        }

                //    }
                //    else
                //    {
                //        if (Validation.isOperator(input.Substring(i, 1)) || i == input.Length - 1)
                //        {
                //            if (i == input.Length - 1)
                //            {
                //                double d = 0.6;
                //                string n = input.Substring(operatorIndex + 1, (i - operatorIndex));
                //                num1 = Decimal.Parse(n, System.Globalization.CultureInfo.InvariantCulture);
                //                //num1 = Convert.ToDecimal(n);
                //            }

                //            else
                //            {
                //                num1 = Convert.ToDecimal(input.Substring(operatorIndex + 1, (i-1) - (operatorIndex)));
                //            }

                //            if (input.Substring(operatorIndex, 1)=="+")
                //            {
                //                total = Operators.Add(total,num1);
                //            }

                //            else if (input.Substring(operatorIndex, 1) == "-")
                //            {
                //                total = Operators.Subtract(total, num1);
                //            }

                //            else if (input.Substring(operatorIndex, 1) == "x")
                //            {
                //                total = Operators.Multiply(total, num1);
                //            }

                //            else if (input.Substring(operatorIndex, 1) == "/")
                //            {
                //                total = Operators.Divide(total, num1);
                //            }

                //            operatorIndex = i;
                //        }
                //    }
                //    if (i == input.Length-1)
                //    {
                //        input = total.ToString();
                //    }


                //}
            }

            return input;
        }
    }
    
}
