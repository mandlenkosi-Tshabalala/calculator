﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrderwiseCalculator
{
    public partial class OrderwiseCalculator : Form
    {
        public OrderwiseCalculator()
        {
            InitializeComponent();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";
            }
            this.Display.Text = "";
        }

        private void CE_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }

            if (this.Display.Text.Length > 0)
            {
                this.Display.Text = this.Display.Text.Substring(0, this.Display.Text.Length - 1);
            }
        }

        private void StepBack_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }

            if (this.Display.Text.Length > 0)
            {
                this.Display.Text = this.Display.Text.Substring(0, this.Display.Text.Length - 1);
            }

        }

        private void Equals_Click(object sender, EventArgs e)
        {
            this.Display.Text = Operators.CalculationLogic(this.Display.Text);
        }

        private void Zero_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Zero.Text;
        }

        private void Comma_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }

            if (this.Display.Text == "")
            {
                this.Display.Text = "0" + this.Comma.Text;
            }

            else
            {
                this.Display.Text += this.Comma.Text;
            }

        }

        private void One_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.One.Text;
        }

        private void Two_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Two.Text;
        }

        private void Three_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Three.Text;
        }

        private void Multiply_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }

            if (this.Display.Text == "")
            {
                this.Display.Text = "0" + this.Multiply.Text;
            }

            else
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += "0" + this.Multiply.Text;
                }

                else
                {
                    this.Display.Text += this.Multiply.Text;
                }
            }



        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            if (this.Display.Text == "")
            {
                this.Display.Text = "0" + this.Add.Text;
            }

            else
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += "0" + this.Add.Text;
                }

                else
                {
                    this.Display.Text += this.Add.Text;
                }
            }
        }

        private void Divide_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            if (this.Display.Text == "")
            {
                this.Display.Text = "0" + this.Divide.Text;
            }

            else
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += "0" + this.Divide.Text;
                }

                else
                {
                    this.Display.Text += this.Divide.Text;
                }
            }
        }

        private void Minus_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";
            }
            if (this.Display.Text == "")
            {
                this.Display.Text = "0" + this.Minus.Text;
            }

            else
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += "0" + this.Minus.Text;
                }

                else
                {
                    this.Display.Text += this.Minus.Text;
                }
            }

        }

        private void Six_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Six.Text;
        }

        private void Five_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Five.Text;
        }

        private void Four_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Four.Text;
        }

        private void Seven_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";
            }
            this.Display.Text += this.Seven.Text;
        }

        private void Eight_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Eight.Text;
        }

        private void Nine_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += this.Nine.Text;
        }

        private void Negate_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }
            this.Display.Text += "-";
        }

        private void Squared_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }

            if (this.Display.Text == "")
            {
                this.Display.Text = "0" + "²";
            }

            else
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += "0" + "²";
                }

                else
                {
                    this.Display.Text += "²";
                }
            }
        }

        private void SquareRoot_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";
                return;
            }

            if (this.Display.Text.Length > 0)
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += "√0";
                }


                else
                {
                    if ( this.Display.Text.Substring(this.Display.Text.Length - 1) != "²")
                    {
                        var firstPart = "";
                        var position = 0;
                        for (int i = this.Display.Text.Length - 2; i > 0; i--)
                        {
                            if (Validation.isOperator(this.Display.Text.Substring(i, 1)))
                            {
                                firstPart = this.Display.Text.Substring(0, i + 1);
                                position = i + 1;
                                break;
                            }
                        }
                        this.Display.Text = firstPart + "√" + this.Display.Text.Substring(position);
                    }
                    
                }
            }

            else
            {
                this.Display.Text = "√0";
            }

        }

        private void OverOne_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";
                return;
            }

            if (this.Display.Text.Length > 0)
            {
                if (!Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length - 1)) && this.Display.Text.Substring(this.Display.Text.Length - 1)!= "²")
                {
                    this.Display.Text += 1 + "/" + "0";
                }


                else
                {
                    var firstPart = "";
                    var position = 0;
                    for (int i = this.Display.Text.Length - 2; i > 0; i--)
                    {
                        if (Validation.isOperator(this.Display.Text.Substring(i, 1)))
                        {
                            firstPart = this.Display.Text.Substring(0, this.Display.Text.Length + 1 - i);
                            position = i + 1;
                            break;
                        }
                    }
                    this.Display.Text = this.Display.Text.Substring(0, position + 1) + 1 + "/" + this.Display.Text.Substring(position);
                }
            }

            else
            {
                this.Display.Text = 1 + "/" + "0"; ;
            }
        }

        private void Percent_Click(object sender, EventArgs e)
        {
            if (this.Display.Text.Equals("Nothing entered") || this.Display.Text.Equals("Input entered is not valid") || this.Display.Text.Equals("Attempted to divide by zero"))
            {
                this.Display.Text = "";

            }

            if (Validation.isNumber(this.Display.Text.Substring(this.Display.Text.Length-1, 1)))
            {
                decimal num1 = 0;
                for (int i = this.Display.Text.Length-1; i >= 0; i--)
                {
                    if (Validation.isOperator(this.Display.Text.Substring(i, 1)) || i == 0)
                    {
                        if (i == 0)
                        {
                            string stringNum1 = this.Display.Text.Substring(i);
                            if (stringNum1.Contains(","))
                            {
                                num1 = Convert.ToDecimal(stringNum1);
                            }

                            else
                            {
                                num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                            }

                            this.Display.Text = Operators.Pencent(num1).ToString();
                            break;
                        }

                        else
                        {
                            string stringNum1 = this.Display.Text.Substring(i+1);
                            if (stringNum1.Contains(","))
                            {
                                num1 = Convert.ToDecimal(stringNum1);
                            }

                            else
                            {
                                num1 = Decimal.Parse(stringNum1, System.Globalization.CultureInfo.InvariantCulture);

                            }

                            this.Display.Text = this.Display.Text.Substring(0, i+1 ) + Operators.Pencent(num1);
                            break;
                        }

                    }
                }
            }
                
            
        }

        
    }
}
